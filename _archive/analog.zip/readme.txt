Weather Links Webpages

Drag or extract the directory to any desired location.

Run by double clicking the index.html file or any htm file.

index.html basic home page; web server host root directory intercept.

pgstyle.css for quick-change visual asthetics.

/wximages contains the graphic files.

Coded in notepad.
To edit files right click and choose "Open With" via Notepad or any other SIMPLE text editor.
Avoid automatic document formatting programs.